
import { useEffect, useState } from "react";
import { initializeApp } from "firebase/app";
import {
  getStorage,
  ref,
  uploadBytesResumable,
  getDownloadURL,
  listAll
} from "firebase/storage";

const firebaseConfig = {
  apiKey: "AIzaSyDZzppG7ccNQOqhPOicDKWhtJWkx-4fqwA",
  authDomain: "agasobanuyefamily.firebaseapp.com",
  projectId: "agasobanuyefamily",
  storageBucket: "agasobanuyefamily.appspot.com",
  messagingSenderId: "959457663784",
  appId: "1:959457663784:web:baf3da9c4252a23c534e1d"
};

const app = initializeApp(firebaseConfig);
const storage = getStorage(app);

export default function App() {
  const [videos, setVideos] = useState([]);
  const [file, setFile] = useState(null);
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    const fetchVideos = async () => {
      const listRef = ref(storage, "videos/");
      const res = await listAll(listRef);
      const urls = await Promise.all(
        res.items.map(item => getDownloadURL(item))
      );
      setVideos(urls);
    };
    fetchVideos();
  }, []);

  const handleUpload = () => {
    if (!file) return;
    setUploading(true);
    const videoRef = ref(storage, `videos/${file.name}`);
    const uploadTask = uploadBytesResumable(videoRef, file);

    uploadTask.on(
      "state_changed",
      null,
      (error) => {
        console.error("Upload failed:", error);
        setUploading(false);
      },
      () => {
        getDownloadURL(uploadTask.snapshot.ref).then((url) => {
          setVideos(prev => [...prev, url]);
          setUploading(false);
        });
      }
    );
  };

  return (
    <div className="min-h-screen bg-gray-100 p-4 text-center">
      <h1 className="text-3xl font-bold text-purple-800 mb-4">AgasobanuyeFamily 🎥</h1>

      <div className="mb-6">
        <h2 className="text-xl font-semibold">Upload (Owner Only)</h2>
        <input type="file" accept="video/*" onChange={e => setFile(e.target.files[0])} />
        <button
          className="ml-2 px-4 py-2 bg-purple-700 text-white rounded"
          onClick={handleUpload}
          disabled={uploading}
        >
          {uploading ? "Uploading..." : "Upload Video"}
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
        {videos.map((url, idx) => (
          <video key={idx} controls className="w-full rounded shadow">
            <source src={url} type="video/mp4" />
            Your browser does not support the video tag.
          </video>
        ))}
      </div>
    </div>
  );
}
